let moedas = 0;
function ganharMoeda() {
  moedas++;
  document.getElementById('moedas').textContent = moedas;
}
